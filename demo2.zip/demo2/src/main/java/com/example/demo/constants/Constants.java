package com.example.demo.constants;

public class Constants {
	
	public static final String DOT = ".";
	
	public static final String SEMNI_COLOM = ";";
	
	public static final String COMMA = ",";
	
	public static final String CSV_NEW_LINE = "/n";
	
	public static final String ID = "ID";
	
	public static final String INSURER_NUMBER = "InsurerNumber";
	
	public static final String INSURED_NUMBER = "InsuredNumber";
	
	public static final String NAME = "NAME";
	
	public static final String PHONE_NUMBER = "PhoneNumber";
	
	public static final String SERVICE_USER_NUMBER = "ServiceUserNumber";
	
	public static final String CSV_HEADER = "ID,InsurerNumber,InsuredNumber,NAME,PhoneNumber,ServiceUserNumber";
	
	public static final String CSV_EXTENSION = ".csv";
	
	public static final String JSON_EXTENSION = ".json";
	
	public static final String CSV_PREFIX = "ServiceUser_";
	
	public static final String CONTENT_TYPE = "Content-type";
	
	public static final String CONTENT_DISPOSITION = "Content-Disposition";
	
	public static final String SIMPLE_DATE_FORMAT = "yyyyMMddHHmm";
	

}
