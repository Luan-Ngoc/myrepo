package com.example.demo.constants;

/**
 * Common constants service user management
 * 
 * @author LuanDN
 *
 */
public class Constants {
	
	/**
	 * Constants string dot
	 */
	public static final String DOT = ".";
	
	/**
	 * Constants string semicolon
	 */
	public static final String SEMICOLON = ";";
	
	/**
	 * Constants string comma
	 */
	public static final String COMMA = ",";
	
	/**
	 * Constants new line for export CSV
	 */
	public static final String CSV_NEW_LINE = "/n";
	
	/**
	 * Constants ID for service user
	 */
	public static final String ID = "ID";
	
	/**
	 * Constants string insured number of service user
	 */
	public static final String INSURER_NUMBER = "InsurerNumber";
	
	/**
	 * Constants string insured number of service user
	 */
	public static final String INSURED_NUMBER = "InsuredNumber";
	
	/**
	 * Constants string name of service user
	 */
	public static final String NAME = "NAME";
	
	/**
	 * Constants string phone number of service user
	 */
	public static final String PHONE_NUMBER = "PhoneNumber";
	
	/**
	 * Constants string service user number
	 */
	public static final String SERVICE_USER_NUMBER = "ServiceUserNumber";
	
	/**
	 * Constants string header CSV output
	 */
	public static final String CSV_HEADER = "ID,InsurerNumber,InsuredNumber,NAME,PhoneNumber,ServiceUserNumber";
	
	/**
	 * Constants extension CSV file
	 */
	public static final String CSV_EXTENSION = ".csv";
	
	/**
	 * Constants extension JSON file
	 */
	public static final String JSON_EXTENSION = ".json";
	
	/**
	 * Constants String CSV prefix
	 */
	public static final String CSV_PREFIX = "ServiceUser_";
	
	/**
	 * Constants content type of header response entity
	 */
	public static final String CONTENT_TYPE = "Content-type";
	
	/**
	 * Constants content disposition of header response entity
	 */
	public static final String CONTENT_DISPOSITION = "Content-Disposition";
	
	/**
	 * Constants string date time format
	 */
	public static final String SIMPLE_DATE_FORMAT = "yyyyMMddHHmm";
	

}
