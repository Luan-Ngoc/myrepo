package com.example.demo.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.example.demo.exception.AppException;
import com.example.demo.model.ServiceUserHistoryModel;
import com.example.demo.repository.ServiceUserHistoryRepository;
import com.example.demo.service.ServiceUserHistoryService;
import com.example.demo.util.MessageResource;

import java.util.List;

/**
 * Service User History Service Implement
 * 
 * @author luandn
 */
@Service
@Qualifier("ServiceUserHistoryServiceImpl")
public class ServiceUserHistoryServiceImpl implements ServiceUserHistoryService {

	@Autowired
	private ServiceUserHistoryRepository serviceUserHistoryRepository;

	@Override
	public List<ServiceUserHistoryModel> getDetailUpdateHistory(String serviceUserNumber, Long historyNumber) {
		try {
			return serviceUserHistoryRepository.findByServiceUserNumberAndHistoryNumber(serviceUserNumber, historyNumber);
		} catch (Exception e) {
			throw new AppException(HttpStatus.INTERNAL_SERVER_ERROR,
					MessageResource.toMessage(MessageResource.SERVICE_USER_SERVICE, MessageResource.GET_FAIL));
		}
	}

}
