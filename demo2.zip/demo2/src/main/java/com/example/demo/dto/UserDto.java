package com.example.demo.dto;

import java.util.List;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import lombok.Getter;
import lombok.Setter;



@Getter
@Setter
public class UserDto {

	@NotNull(groups = { Existing.class })
	private Long userId;

	@NotBlank(groups = { New.class, Existing.class })
	private String userName;
	
	@NotBlank(groups = { New.class, Existing.class })
	private String password;

	@NotNull(groups = { New.class, Existing.class })
//	@JsonProperty("enabled")
	private boolean enabled;

	@NotEmpty(groups = { New.class, Existing.class })
	private List<RoleDto> roles;

	public UserDto() {

	}

	@Override
	public String toString() {
		return "UserDto {userId=" + userId + ", userName=" + userName + ", roles=" + roles + "}";
	}
	
	/**
	 * 
	 */
	public interface Existing {
	}

	/**
	 * 
	 */
	public interface New {
	}

}
