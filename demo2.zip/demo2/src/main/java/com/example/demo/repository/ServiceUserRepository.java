package com.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.demo.model.ServiceUserModel;

/**
 * Service User Repository interface
 *
 * @author luandn
 */
@Repository
public interface ServiceUserRepository extends  JpaRepository<ServiceUserModel, Long> {
	
	//ServiceUserModel findById(Long id);
	
	/**
	 * Get service user by ID
	 *
	 * @param id
	 * @return ServiceUserModel
	 */
	@Query(value = "SELECT * FROM service_user WHERE id = (:id)", nativeQuery = true)
    ServiceUserModel getById(@Param("id") Long id);
	
	/**
	 * Get service user by name containing
	 *
	 * @param name
	 * @return List<ServiceUserModel>
	 */
	List<ServiceUserModel> findByNameContaining(String name);
	
	
}
