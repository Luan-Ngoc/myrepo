package com.example.demo.service.impl;

import com.example.demo.exception.AppException;
import com.example.demo.model.ServiceUserModel;
import com.example.demo.model.ServiceUserQueryModel;
import com.example.demo.repository.ServiceUserRepository;
import com.example.demo.repository.ServiceUserRepositoryCustom;
import com.example.demo.service.ServiceUserService;
import com.example.demo.util.MessageResource;
import com.example.demo.util.ServiceUserUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Service User Service Implement
 *
 * @author luandn
 */
@Service
@Transactional
@Qualifier("ServiceUserServiceImpl")
public class ServiceUserServiceImpl implements ServiceUserService {
	
	@Autowired
	private ServiceUserRepository serviceUserRepository;

	@Autowired
	private ServiceUserRepositoryCustom serviceUserRepositoryCustom;
	
	@Override
	public List<ServiceUserModel> findByName(String name) {
		try {
			return serviceUserRepository.findByNameContaining(name);
		} catch (Exception e) {
			throw new AppException(HttpStatus.INTERNAL_SERVER_ERROR,
					MessageResource.toMessage(MessageResource.SERVICE_USER_SERVICE, MessageResource.GET_FAIL));
		}
	}
	
	@Override
	public boolean deleteServiceUser(Long id) {

		ServiceUserModel one = null;
		try {
			one = serviceUserRepository.getById(id);
		} catch (Exception e) {
			throw new AppException(HttpStatus.INTERNAL_SERVER_ERROR,
					MessageResource.toMessage(MessageResource.SERVICE_USER_SERVICE, MessageResource.DELETE_FAIL));
		}

		if (one == null) {
			throw new AppException(HttpStatus.INTERNAL_SERVER_ERROR,
					MessageResource.toMessage(MessageResource.SERVICE_USER_SERVICE, MessageResource.DELETE_FAIL));
		} else {
			serviceUserRepository.deleteById(id);
			return true;
		}

	}

	@Override
	public ServiceUserModel save(ServiceUserModel serviceUser) {

		ServiceUserModel one = null;
		try {
			one = serviceUserRepository.getById(serviceUser.getId());
		} catch (Exception e) {
			throw new AppException(HttpStatus.INTERNAL_SERVER_ERROR,
					MessageResource.toMessage(MessageResource.SERVICE_USER_SERVICE, MessageResource.INSERT_FAIL));
		}

		if (one == null) {
			return serviceUserRepository.save(serviceUser);
		} else {
			throw new AppException(HttpStatus.INTERNAL_SERVER_ERROR,
					MessageResource.toMessage(MessageResource.SERVICE_USER_SERVICE, MessageResource.INSERT_FAIL));
		}
	}

	@Override
	public ServiceUserModel update(ServiceUserModel serviceUser) {

		ServiceUserModel one = null;
		try {
			one = serviceUserRepository.getById(serviceUser.getId());

		} catch (Exception e) {
			throw new AppException(HttpStatus.INTERNAL_SERVER_ERROR,
					MessageResource.toMessage(MessageResource.SERVICE_USER_SERVICE, MessageResource.UPDATE_FAIL));
		}

		if(one == null) {
			throw new AppException(HttpStatus.BAD_REQUEST,
					MessageResource.toMessage(MessageResource.SERVICE_USER_SERVICE, MessageResource.UPDATE_FAIL));
		} else {
			return  serviceUserRepository.save(serviceUser);
		}
	}

	@Override
	public List<ServiceUserModel> findAll(ServiceUserQueryModel filter) {

		try {
			// Sorting
			List<String> sort = new ArrayList<String>();
			if (filter.getSort() != null) {
				for (String item : filter.getSort().split(",")) {
					sort.add(item.trim().toLowerCase());
				}
			}

			// Paging
			Integer limit = null;
			Integer offset = null;
			if (filter.getPage() != null && filter.getLimit() != null) {
				limit = Integer.parseInt(filter.getLimit());
				offset = (Integer.parseInt(filter.getPage()) - 1) * limit;
			}

			// Filtering
			List<ServiceUserModel> resultList = serviceUserRepositoryCustom.findAll(filter, sort, limit, offset);
			return resultList;
		} catch (Exception e) {
			throw new AppException(HttpStatus.INTERNAL_SERVER_ERROR,
					MessageResource.toMessage(MessageResource.SERVICE_USER_SERVICE, MessageResource.GET_FAIL));
		}
	}

	@Override
	public Long countAll(ServiceUserQueryModel filter) {
		try {
			return serviceUserRepositoryCustom.countAll(filter);
		} catch (Exception e) {
			throw new AppException(HttpStatus.INTERNAL_SERVER_ERROR,
					MessageResource.toMessage(MessageResource.SERVICE_USER_SERVICE, MessageResource.GET_FAIL));
		}
	}
	
	
	@Override
	public Map<String, String> exportCSVData(ServiceUserQueryModel filter) {
		
		Map<String, String> csvData = new HashMap<>();
		
		List<ServiceUserModel> listResult = findAll(filter);
		
		if(listResult == null || listResult.size() == 0) {
			throw new AppException(HttpStatus.NOT_FOUND,
					MessageResource.toMessage(MessageResource.SERVICE_USER_SERVICE, MessageResource.EXPORT_SUCCESS));
		}
		
		csvData.put("fileName", ServiceUserUtil.buildCSVFileName());
		csvData.put("csvData", ServiceUserUtil.convertToCsv(listResult)) ;
		
		return csvData;
	}
	
	@Override
	public ServiceUserModel upload(Long id, String encoded) {

		ServiceUserModel one = null;
		try {
			one = serviceUserRepository.getById(id);
		} catch (Exception e) {
			throw new AppException(HttpStatus.INTERNAL_SERVER_ERROR,
					MessageResource.toMessage(MessageResource.SERVICE_USER_SERVICE, MessageResource.UPDATE_FAIL));
		}

		if(one == null) {
			throw new AppException(HttpStatus.BAD_REQUEST,
					MessageResource.toMessage(MessageResource.SERVICE_USER_SERVICE, MessageResource.UPDATE_FAIL));
		} else {
			one.setProfilePicture(encoded);
			return serviceUserRepository.save(one);
		}
	}
}
