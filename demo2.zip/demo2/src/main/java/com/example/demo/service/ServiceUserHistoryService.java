package com.example.demo.service;

import org.springframework.stereotype.Service;

import com.example.demo.model.ServiceUserHistoryModel;

import java.util.List;

/**
 * Service User History interface
 *
 * @author luandn
 */
@Service
public interface ServiceUserHistoryService {
	
	/**
	 * Get detail update service user history
	 *
	 * @param serviceUserNumber
	 * @param historyNumber
	 * @return List<ServiceUserHistoryModel>
	 */
	List<ServiceUserHistoryModel> getDetailUpdateHistory(String serviceUserNumber, String historyNumber);

}
