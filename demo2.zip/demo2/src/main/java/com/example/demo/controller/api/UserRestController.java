package com.example.demo.controller.api;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.UserDto;
import com.example.demo.service.UserService;
import com.example.demo.util.MessageResource;
import com.example.demo.util.ResponseEntity;
import com.example.demo.util.ValidationUtil;

@RestController
@RequestMapping("/admin/userAPI")
public class UserRestController {
	
	@Autowired
	UserService userService;
	
	//@PreAuthorize("hasRole('ROLE_ADMIN')")
	@RequestMapping(method = RequestMethod.GET)
	public ResponseEntity<List<UserDto>> searchUser(@RequestParam("userName") String userName) {
		List<UserDto> userDtos = userService.searchUser(userName);
		
		if (userDtos != null) {
			return new ResponseEntity<>(userDtos, HttpStatus.OK,
					MessageResource.toMessage(MessageResource.ADMIN_USERAPI, MessageResource.GET_SUCCESS));
		} else {
			return new ResponseEntity<>(userDtos, HttpStatus.NOT_FOUND,
					MessageResource.toMessage(MessageResource.ADMIN_USERAPI, MessageResource.GET_NO_DATA));
		}
	}
	
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	@RequestMapping(method = RequestMethod.POST)
	public ResponseEntity<UserDto> insertUser(@Validated(UserDto.New.class) @RequestBody UserDto userDto, BindingResult bindingResult) {
		if (bindingResult.hasErrors()) {
			return ValidationUtil.processBindingResultError(bindingResult);

		} else {
			UserDto result = userService.insertUser(userDto);

			if (result != null) {
				return new ResponseEntity<>(result, HttpStatus.OK,
						MessageResource.toMessage(MessageResource.ADMIN_USERAPI, MessageResource.INSERT_SUCCESS));
			} else {
				return new ResponseEntity<>(HttpStatus.NOT_ACCEPTABLE,
						MessageResource.toMessage(MessageResource.ADMIN_USERAPI, MessageResource.INSERT_FAIL));
			}
		}
	}
	
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	@RequestMapping(method = RequestMethod.PUT)
	public ResponseEntity<UserDto> updateUser(@Validated(UserDto.Existing.class) @RequestBody UserDto userDto, BindingResult bindingResult) {
		if (bindingResult.hasErrors()) {
			return ValidationUtil.processBindingResultError(bindingResult);

		} else {
			UserDto result = userService.updateUser(userDto);

			if (result != null) {
				return new ResponseEntity<>(result, HttpStatus.OK,
						MessageResource.toMessage(MessageResource.ADMIN_USERAPI, MessageResource.INSERT_SUCCESS));

			} else {

				return new ResponseEntity<>(HttpStatus.NOT_ACCEPTABLE,
						MessageResource.toMessage(MessageResource.ADMIN_USERAPI, MessageResource.INSERT_FAIL));
			}

		}
	}
	
	@RequestMapping(method = RequestMethod.DELETE)
	public ResponseEntity<Integer> deleteMultipleUser(@RequestBody String userIds) {
		boolean deleteResult = userService.deleteMultipleUser(userIds);
		if (deleteResult) {
			return new ResponseEntity<>(HttpStatus.OK,
					MessageResource.toMessage(MessageResource.ADMIN_USERAPI, MessageResource.DELETE_SUCCESS), userIds);
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_MODIFIED,
					MessageResource.toMessage(MessageResource.ADMIN_USERAPI, MessageResource.DELETE_FAIL), userIds);
		}
	}
}
