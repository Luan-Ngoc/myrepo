package com.example.demo.repository.impl;

import com.example.demo.model.ServiceUserModel;
import com.example.demo.model.ServiceUserQueryModel;
import com.example.demo.repository.ServiceUserRepositoryCustom;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


/**
 * Service User Repository Custom Implement
 * 
 * @author LuanDN
 *
 */
@Component
public class ServiceUserRepositoryCustomImpl implements ServiceUserRepositoryCustom {

    @Autowired
    EntityManager em;

    /**
     * Count all service user that satisfies search condition
     */
    @Override
    public Long countAll(ServiceUserQueryModel query) {

        CriteriaBuilder builder = em.getCriteriaBuilder();
        CriteriaQuery<Long> criteriaQuery = builder.createQuery(Long.class);
        Root<ServiceUserModel> root = criteriaQuery.from(ServiceUserModel.class);
        criteriaQuery.select(builder.count(root));

        List<Predicate> conditionList = buildConditionList(query, root);

        if( conditionList.size() > 0 ){
            criteriaQuery.where(conditionList.toArray(new Predicate[conditionList.size()]));
        }

        return em.createQuery(criteriaQuery).getSingleResult().longValue();
    }

    /**
     * Search all service user that satisfies condition and support paging
     */
    @Override
    public List<ServiceUserModel> findAll(ServiceUserQueryModel query, List<String> sort, Integer limit, Integer offset) {

        CriteriaBuilder builder = em.getCriteriaBuilder();
        CriteriaQuery<ServiceUserModel> criteriaQuery = builder.createQuery(ServiceUserModel.class);
        Root<ServiceUserModel> root = criteriaQuery.from(ServiceUserModel.class);
        List<Predicate> conditionList = buildConditionList(query, root);

        if(conditionList.size() > 0){
            criteriaQuery.where(conditionList.toArray(new Predicate[conditionList.size()]));
        }

        if (sort.size() > 0) {
            List<Order> orderList = new ArrayList<Order>();
            for (String col : sort) {
                if (col.startsWith("-")) {
                    // DESC sorting
                    orderList.add(builder.desc(root.get(col.substring(1))));
                } else {
                    // ASC sorting
                    orderList.add(builder.asc(root.get(col)));
                }
            }
            criteriaQuery.orderBy(orderList);
        }

        TypedQuery<ServiceUserModel> q = em.createQuery(criteriaQuery);

        if (offset != null) {
        	q.setFirstResult(offset);
        }
        
        if (limit != null) {
        	q.setMaxResults(limit);
        }

        return q.getResultList();
    }

    /**
     * Build search condition
     * 
     * @param query
     * @param root
     * @return
     */
    private List<Predicate> buildConditionList(ServiceUserQueryModel query, Root<ServiceUserModel> root) {
        List<Predicate> conditionList = new ArrayList<>();

        if (query.getInsurerNumber() != null && query.getInsurerNumber().length > 0) {
            conditionList.add(root.get("insurerNumber").in(Arrays.asList(query.getInsurerNumber())));
        }

        if (query.getInsuredNumber() != null && query.getInsuredNumber().length > 0) {
            conditionList.add(root.get("insuredNumber").in(Arrays.asList(query.getInsuredNumber())));
        }

        if (query.getName() != null && query.getName().length > 0) {
            conditionList.add(root.get("name").in(Arrays.asList(query.getName())));
        }

        if (query.getPhoneNumber() != null && query.getPhoneNumber().length > 0) {
            conditionList.add(root.get("phoneNumber").in(Arrays.asList(query.getPhoneNumber())));
        }

        if (query.getServiceUserNumber() != null && query.getServiceUserNumber().length > 0) {
            conditionList.add(root.get("serviceUserNumber").in(Arrays.asList(query.getServiceUserNumber())));
        }

        return conditionList;
    }
}
