package com.example.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Getter 
@Setter

@Entity
@Table(name = "Service_User")
public class ServiceUserModel {
	
	@Id
    @Column(name = "id", nullable = false)
    private Long id;
	
	@Column(name = "insurer_number", nullable = false)
    private String insurerNumber;

    @Column(name = "insured_number", nullable = false)
    private String insuredNumber;

    @Column(name = "service_user_number", nullable = false)
    private String serviceUserNumber;

	@Column(name = "name", nullable = false)
    private String name;
	
	@Column(name = "gender")
    private String gender;
	
	@Column(name = "birthday")
    private String birthday;
	
	@Column(name = "address")
    private String address;
	
	@Column(name = "phone_number")
    private String phoneNumber;
	
	@Column(name = "care_period_start_date")
    private String carePeriodStartDate;
	
	@Column(name = "care_period_end_date")
    private String carePeriodEndDate;
	
	@Column(name = "profile_picture")
    private String profilePicture;
}
