package com.example.demo.annotation;

/**
 * The Timed interface
 */
public @interface Timed {

}
