package com.example.demo.service;

import org.springframework.stereotype.Service;

import com.example.demo.dto.UserDto;

import java.util.List;

import org.springframework.security.core.userdetails.UserDetailsService;

@Service
public interface UserService  extends UserDetailsService {
	UserDto findByUserName(String userName);
	
	List<UserDto> searchUser(String userName);
	
	List<UserDto> getAllUserByRole(List<Long> roleIds);
	
	UserDto insertUser(UserDto userDto);
	
	UserDto updateUser(UserDto userDto);
	
	boolean deleteUser(Long userId);
	
	boolean deleteMultipleUser(String userIds);
	
}
