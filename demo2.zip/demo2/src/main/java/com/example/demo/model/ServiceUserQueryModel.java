package com.example.demo.model;

import java.io.Serializable;
import java.util.StringJoiner;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Data
public class ServiceUserQueryModel implements Serializable {

    private static final long serialVersionUID = 1L;

    private String[] insurerNumber;

    private String[] insuredNumber;

    private String[] name;

    private String[] phoneNumber;

    private String[] serviceUserNumber;

    private String sort;

    private String page;

    private String limit;

    public String buildUrlParameter() {
        StringJoiner sj = new StringJoiner("&", "?", "");
        sj.setEmptyValue("");

        if (insurerNumber != null) for (String s : insurerNumber) sj.add("insurer_number=" + s);

        if (insuredNumber != null) for (String s : insuredNumber) sj.add("insured_number=" + s);

        if (name != null) for (String s : name) sj.add("name=" + s);

        if (phoneNumber != null) for (String s : phoneNumber) sj.add("phone_number=" + s);

        if (serviceUserNumber != null) for (String s : serviceUserNumber) sj.add("service_user_number" + s);

        if (sort != null) sj.add("sort=" + sort);

        if (page != null) sj.add("page=" + page);

        if (limit != null) sj.add("limit=" + limit);

        return sj.toString();
    }

}
