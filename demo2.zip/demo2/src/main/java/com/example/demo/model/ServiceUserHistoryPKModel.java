package com.example.demo.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

import lombok.Getter;
import lombok.Setter;


/**
 * Service User History Primary Key
 * 
 * @author luandn
 */
@Getter 
@Setter
@Embeddable
public class ServiceUserHistoryPKModel implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@Column(name = "id", nullable = false)
	private Long id;
	
	@Column(name = "history_number", nullable = false)
	private Long historyNumber;
	
	public ServiceUserHistoryPKModel() {
		
    }

	public ServiceUserHistoryPKModel(Long id, Long historyNumber) {
		super();
		this.id = id;
		this.historyNumber = historyNumber;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((historyNumber == null) ? 0 : historyNumber.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ServiceUserHistoryPKModel other = (ServiceUserHistoryPKModel) obj;
		if (historyNumber == null) {
			if (other.historyNumber != null)
				return false;
		} else if (!historyNumber.equals(other.historyNumber))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}
	
}
