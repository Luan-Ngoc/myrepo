package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.demo.model.ServiceUserHistoryModel;
import com.example.demo.model.ServiceUserHistoryPKModel;

import java.util.List;

/**
 * Service User History Repository interface
 *
 * @author luandn
 */
@Repository
public interface ServiceUserHistoryRepository extends JpaRepository<ServiceUserHistoryModel, ServiceUserHistoryPKModel> {
	
	/**
	 * Get detail update service user history
	 *
	 * @param serviceUserNumber
	 * @param historyNumber
	 * @return List<ServiceUserHistoryModel>
	 */
	@Query(value = "SELECT * FROM service_user_history WHERE service_user_number = (:serviceUserNumber)"
			+ " AND history_number = (:historyNumber)", nativeQuery = true)
	List<ServiceUserHistoryModel> findByServiceUserNumberAndHistoryNumber(@Param("serviceUserNumber") String serviceUserNumber,
			@Param("historyNumber") Long historyNumber);

}
