package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.model.ServiceUserHistoryModel;

import java.util.List;

/**
 * Service User History Repository interface
 *
 * @author luandn
 */
@Repository
public interface ServiceUserHistoryRepository extends JpaRepository<ServiceUserHistoryModel, Long> {
	
	/**
	 * Get detail update service user history
	 *
	 * @param serviceUserNumber
	 * @param historyNumber
	 * @return List<ServiceUserHistoryModel>
	 */
	List<ServiceUserHistoryModel> findByServiceUserNumberAndHistoryNumber(String serviceUserNumber, String historyNumber);

}
