package com.example.demo.service;

import java.util.List;
import java.util.Map;

import com.example.demo.model.ServiceUserQueryModel;
import org.springframework.stereotype.Service;

import com.example.demo.model.ServiceUserModel;

import javax.transaction.Transactional;

@Service
@Transactional
public interface ServiceUserService {
	
	List<ServiceUserModel> findByName(String name);
	
	boolean deleteServiceUser(Long id);

	ServiceUserModel save(ServiceUserModel serviceUser);

	ServiceUserModel update(ServiceUserModel serviceUser);

	List<ServiceUserModel> findAll(ServiceUserQueryModel filter);

	Long countAll(ServiceUserQueryModel filter);
	
	Map<String, List<String>> exportCSVData(ServiceUserQueryModel filter);
	
	ServiceUserModel upload(Long id, String encoded);

}
