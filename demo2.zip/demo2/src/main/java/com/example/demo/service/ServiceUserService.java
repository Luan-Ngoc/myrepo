package com.example.demo.service;

import com.example.demo.model.ServiceUserModel;
import com.example.demo.model.ServiceUserQueryModel;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * Service User interface
 *
 * @author luandn
 */
@Service
public interface ServiceUserService {
	
	/**
	 * Search service user by name
	 *
	 * @param name
	 * @return List<ServiceUserModel>
	 */
	List<ServiceUserModel> findByName(String name);
	
	/**
	 * delete service user by id
	 *
	 * @param id
	 * @return boolean
	 */
	boolean deleteServiceUser(Long id);

	/**
	 * create new service user
	 *
	 * @param serviceUser
	 * @return ServiceUserModel
	 */
	ServiceUserModel save(ServiceUserModel serviceUser);

	/**
	 * update service user
	 *
	 * @param serviceUser
	 * @return ServiceUserModel
	 */
	ServiceUserModel update(ServiceUserModel serviceUser);

	/**
	 * Search service user by condition
	 *
	 * @param filter
	 * @return List<ServiceUserModel>
	 */
	List<ServiceUserModel> findAll(ServiceUserQueryModel filter);

	/**
	 * Count all service user that satisfies condition
	 *
	 * @param filter
	 * @return Long
	 */
	Long countAll(ServiceUserQueryModel filter);
	
	/**
	 * Search service user by condition and export CSV data
	 *
	 * @param filter
	 * @return Map<String, List<String>>
	 */
	Map<String, String> exportCSVData(ServiceUserQueryModel filter);
	
	/**
	 * save profile picture
	 *
	 * @param id
	 * @param encoded
	 * @return ServiceUserModel
	 */
	ServiceUserModel upload(Long id, String encoded);

}
