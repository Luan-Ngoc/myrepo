package com.example.demo.repository;

import com.example.demo.model.ServiceUserModel;
import com.example.demo.model.ServiceUserQueryModel;

import java.util.List;

/**
 * Service User Repository Custom interface
 *
 * @author luandn
 */
public interface ServiceUserRepositoryCustom {

    /**
     * Search service user by condition
     *
     * @param query
     * @param sort
     * @param limit
     * @param offset
     * @return List<ServiceUserModel>
     */
    List<ServiceUserModel> findAll(ServiceUserQueryModel query, List<String> sort, Integer limit, Integer offset);

    /**
     * Count all service user that satisfies condition
     *
     * @param query
     * @return Long
     */
    Long countAll(ServiceUserQueryModel query);
}
