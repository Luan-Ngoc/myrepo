package com.example.demo.repository;

import com.example.demo.model.ServiceUserModel;
import com.example.demo.model.ServiceUserQueryModel;

import java.util.List;

public interface ServiceUserRepositoryCustom {

    List<ServiceUserModel> findAll(ServiceUserQueryModel query, List<String> sort, Integer limit, Integer offset);

    Long countAll(ServiceUserQueryModel query);
}
