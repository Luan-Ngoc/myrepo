package com.example.demo.util;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.example.demo.constants.Constants;
import com.example.demo.model.ServiceUserModel;

public class ServiceUserUtil {
	
	public static String buildOneRow(ServiceUserModel serviceUser) {
		
		StringBuilder oneRow = new StringBuilder();
		if(oneRow != null) {
			oneRow.append(serviceUser.getId());
			oneRow.append(Constants.COMMA);
			
			oneRow.append(serviceUser.getInsurerNumber());
			oneRow.append(Constants.COMMA);
			
			oneRow.append(serviceUser.getInsuredNumber());
			oneRow.append(Constants.COMMA);
			
			oneRow.append(serviceUser.getName());
			oneRow.append(Constants.COMMA);
			
			oneRow.append(serviceUser.getPhoneNumber());
			oneRow.append(Constants.COMMA);
			
			oneRow.append(serviceUser.getServiceUserNumber());
			oneRow.append(Constants.CSV_NEW_LINE);
		}
		
		return oneRow.toString();
	}
	
	public static List<String> convertToCsv(List<ServiceUserModel> listResult) {
		
		List<String> results = new ArrayList<>();
		
		// Add header
		results.add(Constants.CSV_HEADER + Constants.CSV_NEW_LINE);
		
		// Add body
		if(listResult != null) {
			for (ServiceUserModel one : listResult) {
				results.add(buildOneRow(one));
			}
		}
		
		return results;
	}
	
	public static String buildCSVFileName() {
		
		String pattern = Constants.SIMPLE_DATE_FORMAT;
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
		String date = simpleDateFormat.format(new Date());
		
		return Constants.CSV_PREFIX + date + Constants.CSV_EXTENSION;
	}
}
