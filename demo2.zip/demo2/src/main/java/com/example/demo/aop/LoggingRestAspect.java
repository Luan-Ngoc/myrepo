package com.example.demo.aop;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * Capture Activity REST API
 * 
 * @author LuanDN
 *
 */
@Aspect
@Component
public class LoggingRestAspect {
	
	/**
	 * Logger for rest api
	 */
	private static final Logger logger = LoggerFactory.getLogger(LoggingRestAspect.class);
	
	/**
	 * Capture all activity before call API
	 * 
	 * @param joinPoint
	 */
	@Before(value = "execution(public com.example.demo.util.ResponseEntity *(..))")
	public void captureRestApi(JoinPoint joinPoint) {
		
		String method = joinPoint.getSignature().getName();

		String className  = joinPoint.getSignature().getDeclaringTypeName();

		logger.info("START CALL: Method: [{}], Class Name: [{}]", method, className);
	}

}
