package com.example.demo.controller.api;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.example.demo.model.ServiceUserQueryModel;

import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.example.demo.constants.Constants;
import com.example.demo.model.ServiceUserModel;
import com.example.demo.service.ServiceUserService;
import com.example.demo.util.MessageResource;
import com.example.demo.util.ResponseEntity;

@RestController
@RequestMapping("/admin/service_user")
public class ServiceUserAPIController {
	
	@Autowired
	ServiceUserService serviceUser;
	
	@RequestMapping(method = RequestMethod.GET)
	public ResponseEntity<List<ServiceUserModel>> index(@RequestParam("name") String name) {
		List<ServiceUserModel> serviceUsers = serviceUser.findByName(name);
		
		if (serviceUsers != null) {
			return new ResponseEntity<>(serviceUsers, HttpStatus.OK,
					MessageResource.toMessage(MessageResource.ADMIN_SERVICE_USER, MessageResource.GET_SUCCESS));
		} else {
			return new ResponseEntity<>(serviceUsers, HttpStatus.NOT_FOUND,
					MessageResource.toMessage(MessageResource.ADMIN_SERVICE_USER, MessageResource.GET_NO_DATA));
		}
		
	}
	
	@RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
	public ResponseEntity<Integer> delete(@PathVariable(value = "id") String idStr) {

		Long id = null;
		try {
			id = Long.parseLong(idStr);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST,
					MessageResource.toMessage(MessageResource.ADMIN_SERVICE_USER, MessageResource.DELETE_FAIL), idStr);
		}

		boolean result = serviceUser.deleteServiceUser(id);
		if (result) {
			return new ResponseEntity<>(HttpStatus.OK,
					MessageResource.toMessage(MessageResource.ADMIN_SERVICE_USER, MessageResource.DELETE_SUCCESS), id);
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_MODIFIED,
					MessageResource.toMessage(MessageResource.ADMIN_SERVICE_USER, MessageResource.DELETE_FAIL), id);
		}
	}

	@RequestMapping(method = RequestMethod.POST)
	public ResponseEntity<ServiceUserModel> create(@RequestBody ServiceUserModel model) {

		ServiceUserModel result = serviceUser.save(model);

		if (result != null) {
			return new ResponseEntity<>(result, HttpStatus.OK,
					MessageResource.toMessage(MessageResource.ADMIN_SERVICE_USER, MessageResource.INSERT_SUCCESS));
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_ACCEPTABLE,
					MessageResource.toMessage(MessageResource.ADMIN_SERVICE_USER, MessageResource.INSERT_FAIL));
		}
	}

	@RequestMapping(value="/{id}", method = RequestMethod.PUT)
	public ResponseEntity<ServiceUserModel> update(@PathVariable(value = "id") String idStr, @RequestBody ServiceUserModel model) {
		
		Long id = null;
		try {
			id = Long.parseLong(idStr);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST,
					MessageResource.toMessage(MessageResource.ADMIN_SERVICE_USER, MessageResource.DELETE_FAIL), idStr);
		}
		
		model.setId(id);
		ServiceUserModel result = serviceUser.update(model);

		if (result != null) {
			return new ResponseEntity<>(result, HttpStatus.OK,
					MessageResource.toMessage(MessageResource.ADMIN_SERVICE_USER, MessageResource.UPDATE_SUCCESS));
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_ACCEPTABLE,
					MessageResource.toMessage(MessageResource.ADMIN_SERVICE_USER, MessageResource.UPDATE_FAIL));
		}
	}

	@RequestMapping(value="/list", method = RequestMethod.GET)
	public ResponseEntity<List<ServiceUserModel>> search(@ModelAttribute ServiceUserQueryModel queryModel) {

		if (queryModel.getPage() != null && queryModel.getLimit() != null) {
			Integer page = Integer.parseInt(queryModel.getPage());
			Integer limit = Integer.parseInt(queryModel.getLimit());

			Long count = serviceUser.countAll(queryModel);

			if(count == 0) {
				return new ResponseEntity<>(new ArrayList<ServiceUserModel>(), HttpStatus.OK,
						MessageResource.toMessage(MessageResource.ADMIN_SERVICE_USER, MessageResource.GET_SUCCESS));
			}

			int totalPage = count.intValue() / limit;
			totalPage += (count.intValue() % limit > 0) ? 1 : 0;
			page = (totalPage <= page) ? totalPage : page;

			queryModel.setPage(String.valueOf(page));
		}

		List<ServiceUserModel> resultList = serviceUser.findAll(queryModel);

		return new ResponseEntity<>(resultList, HttpStatus.OK,
				MessageResource.toMessage(MessageResource.ADMIN_SERVICE_USER, MessageResource.GET_SUCCESS));
	}

	@RequestMapping(value="/export", method = RequestMethod.GET)
	public ResponseEntity<List<String>> export(@ModelAttribute ServiceUserQueryModel queryModel) {
		
		Map<String, List<String>> csvData = serviceUser.exportCSVData(queryModel);

		Map<String, String> header = new HashMap<>();
		header.put(Constants.CONTENT_DISPOSITION, "attachment; filename=" + csvData.get("fileName").get(0));
		
		return new ResponseEntity<>(csvData.get("csvData"), header, HttpStatus.OK,
				MessageResource.toMessage(MessageResource.ADMIN_SERVICE_USER, MessageResource.GET_SUCCESS));
	}
	
	@RequestMapping(value="/upload/{id}", method = RequestMethod.POST)
	public ResponseEntity<ServiceUserModel> upload(@PathVariable(value = "id") String idStr, @RequestParam("file") MultipartFile file) {
		
		Long id = null;
		ServiceUserModel uploaded = null;
		byte[] bytes = null;
		
		try {
			id = Long.parseLong(idStr);
			bytes = file.getBytes();
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST,
					MessageResource.toMessage(MessageResource.ADMIN_SERVICE_USER, MessageResource.DELETE_FAIL), idStr);
		}
		
		uploaded =  serviceUser.upload(id, new String(Base64.encodeBase64(bytes)));
		
		if(uploaded != null) {
			return new ResponseEntity<>(uploaded, HttpStatus.OK,
					MessageResource.toMessage(MessageResource.ADMIN_SERVICE_USER, MessageResource.UPDATE_SUCCESS));
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_ACCEPTABLE,
					MessageResource.toMessage(MessageResource.ADMIN_SERVICE_USER, MessageResource.UPDATE_FAIL));
		}
		
	}
	
	

}
