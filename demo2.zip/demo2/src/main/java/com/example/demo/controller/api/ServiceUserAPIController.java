package com.example.demo.controller.api;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.example.demo.model.ServiceUserQueryModel;

import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.example.demo.constants.Constants;
import com.example.demo.model.ServiceUserHistoryModel;
import com.example.demo.model.ServiceUserModel;
import com.example.demo.service.ServiceUserHistoryService;
import com.example.demo.service.ServiceUserService;
import com.example.demo.util.MessageResource;
import com.example.demo.util.ResponseEntity;


/**
 * Service User Management API
 * 
 * @author LuanDN
 */
@RestController
@RequestMapping("/admin/service_user")
public class ServiceUserAPIController {
	
	/**
	 * Service User
	 */
	@Autowired
	@Qualifier("ServiceUserServiceImpl")
	ServiceUserService serviceUser;
	
	/**
	 * Service User History
	 */
	@Autowired
	@Qualifier("ServiceUserHistoryServiceImpl")
	ServiceUserHistoryService serviceUserHistory;
	
	/**
	 * Search service user by name
	 * 
	 * @param name
	 * @return ResponseEntity<List<ServiceUserModel>>
	 */
	@RequestMapping(method = RequestMethod.GET)
	public ResponseEntity<List<ServiceUserModel>> index(@RequestParam("name") String name) {
		List<ServiceUserModel> serviceUsers = serviceUser.findByName(name);
		
		if (serviceUsers != null) {
			return new ResponseEntity<>(serviceUsers, HttpStatus.OK,
					MessageResource.toMessage(MessageResource.ADMIN_SERVICE_USER, MessageResource.GET_SUCCESS));
		} else {
			return new ResponseEntity<>(serviceUsers, HttpStatus.NOT_FOUND,
					MessageResource.toMessage(MessageResource.ADMIN_SERVICE_USER, MessageResource.GET_NO_DATA));
		}
		
	}
	
	/**
	 * Delete service user
	 * 
	 * @param idStr
	 * @return ResponseEntity<Integer>
	 */
	@RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
	public ResponseEntity<Integer> delete(@PathVariable(value = "id") String idStr) {

		Long id = null;
		try {
			id = Long.parseLong(idStr);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST,
					MessageResource.toMessage(MessageResource.ADMIN_SERVICE_USER, MessageResource.DELETE_FAIL), idStr);
		}

		boolean result = serviceUser.deleteServiceUser(id);
		if (result) {
			return new ResponseEntity<>(HttpStatus.OK,
					MessageResource.toMessage(MessageResource.ADMIN_SERVICE_USER, MessageResource.DELETE_SUCCESS), id);
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_MODIFIED,
					MessageResource.toMessage(MessageResource.ADMIN_SERVICE_USER, MessageResource.DELETE_FAIL), id);
		}
	}

	/**
	 * Register new service user
	 * 
	 * @param model
	 * @return ResponseEntity<ServiceUserModel>
	 */
	@RequestMapping(method = RequestMethod.POST)
	public ResponseEntity<ServiceUserModel> create(@RequestBody ServiceUserModel model) {

		ServiceUserModel result = serviceUser.save(model);

		if (result != null) {
			return new ResponseEntity<>(result, HttpStatus.OK,
					MessageResource.toMessage(MessageResource.ADMIN_SERVICE_USER, MessageResource.INSERT_SUCCESS));
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_ACCEPTABLE,
					MessageResource.toMessage(MessageResource.ADMIN_SERVICE_USER, MessageResource.INSERT_FAIL));
		}
	}

	/**
	 * Update exist service user information
	 * 
	 * @param idStr
	 * @param model
	 * @return ResponseEntity<ServiceUserModel>
	 */
	@RequestMapping(value="/{id}", method = RequestMethod.PUT)
	public ResponseEntity<ServiceUserModel> update(@PathVariable(value = "id") String idStr, @RequestBody ServiceUserModel model) {
		
		Long id = null;
		try {
			id = Long.parseLong(idStr);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST,
					MessageResource.toMessage(MessageResource.ADMIN_SERVICE_USER, MessageResource.DELETE_FAIL), idStr);
		}
		
		model.setId(id);
		ServiceUserModel result = serviceUser.update(model);

		if (result != null) {
			return new ResponseEntity<>(result, HttpStatus.OK,
					MessageResource.toMessage(MessageResource.ADMIN_SERVICE_USER, MessageResource.UPDATE_SUCCESS));
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_ACCEPTABLE,
					MessageResource.toMessage(MessageResource.ADMIN_SERVICE_USER, MessageResource.UPDATE_FAIL));
		}
	}

	/**
	 * Search condition includes: Insurer Number, Insured Number, Name,
	 * Phone Number and Service User Number.
	 * It is also the information that will display on the result list
	 * 
	 * @param queryModel
	 * @return ResponseEntity<List<ServiceUserModel>>
	 */
	@RequestMapping(value="/list", method = RequestMethod.GET)
	public ResponseEntity<List<ServiceUserModel>> search(@ModelAttribute ServiceUserQueryModel queryModel) {

		if (queryModel.getPage() != null && queryModel.getLimit() != null) {
			
			Integer page = Integer.parseInt(queryModel.getPage());
			Integer limit = Integer.parseInt(queryModel.getLimit());
			
			// Count all service user that satisfies search condition
			Long count = serviceUser.countAll(queryModel);

			if(count == 0) {
				return new ResponseEntity<>(new ArrayList<ServiceUserModel>(), HttpStatus.OK,
						MessageResource.toMessage(MessageResource.ADMIN_SERVICE_USER, MessageResource.GET_SUCCESS));
			}
			
			// Supported paging
			int totalPage = count.intValue() / limit;
			totalPage += (count.intValue() % limit > 0) ? 1 : 0;
			// If input page > total page then direct page to the end page
			page = (totalPage <= page) ? totalPage : page;

			queryModel.setPage(String.valueOf(page));
		}

		List<ServiceUserModel> resultList = serviceUser.findAll(queryModel);

		return new ResponseEntity<>(resultList, HttpStatus.OK,
				MessageResource.toMessage(MessageResource.ADMIN_SERVICE_USER, MessageResource.GET_SUCCESS));
	}

	/**
	 * Export service user data to CSV
	 * Search condition includes: Insurer Number, Insured Number, Name,
	 * Phone Number and Service User Number.
	 * 
	 * @param queryModel
	 * @return ResponseEntity<String>
	 */
	@RequestMapping(value="/export", method = RequestMethod.GET)
	public ResponseEntity<String> export(@ModelAttribute ServiceUserQueryModel queryModel) {
		
		Map<String, String> csvData = serviceUser.exportCSVData(queryModel);

		Map<String, String> header = new HashMap<>();
		header.put(Constants.CONTENT_DISPOSITION, "attachment; filename=" + csvData.get("fileName"));
		
		return new ResponseEntity<>(csvData.get("csvData"), header, HttpStatus.OK,
				MessageResource.toMessage(MessageResource.ADMIN_SERVICE_USER, MessageResource.GET_SUCCESS));
	}
	
	/**
	 * Upload Profile Picture
	 * 
	 * @param idStr
	 * @param file
	 * @return ResponseEntity<ServiceUserModel>
	 */
	@RequestMapping(value="/upload/{id}", method = RequestMethod.POST)
	public ResponseEntity<ServiceUserModel> upload(@PathVariable(value = "id") String idStr, @RequestParam("file") MultipartFile file) {
		
		Long id = null;
		ServiceUserModel uploaded = null;
		byte[] bytes = null;
		
		try {
			id = Long.parseLong(idStr);
			bytes = file.getBytes();
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST,
					MessageResource.toMessage(MessageResource.ADMIN_SERVICE_USER, MessageResource.DELETE_FAIL), idStr);
		}
		
		// Encoded image to base64 format before upload
		uploaded =  serviceUser.upload(id, new String(Base64.encodeBase64(bytes)));
		
		if(uploaded != null) {
			return new ResponseEntity<>(uploaded, HttpStatus.OK,
					MessageResource.toMessage(MessageResource.ADMIN_SERVICE_USER, MessageResource.UPDATE_SUCCESS));
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_ACCEPTABLE,
					MessageResource.toMessage(MessageResource.ADMIN_SERVICE_USER, MessageResource.UPDATE_FAIL));
		}
	}
	
	/**
	 * View detail information and ‘update history’ information of service user.
	 * 
	 * @param serviceUserNumber
	 * @param historyNumber
	 * @return ResponseEntity<List<ServiceUserHistoryModel>>
	 */
	@RequestMapping(value="/{service_user_number}", method = RequestMethod.GET)
	public ResponseEntity<List<ServiceUserHistoryModel>> detailHistory(
			@PathVariable(value = "service_user_number") String serviceUserNumber,
			@RequestParam(value = "r") String historyNumberStr) {
		
		Long historyNumber = null;
		try {
			historyNumber = Long.parseLong(historyNumberStr);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST,
					MessageResource.toMessage(MessageResource.ADMIN_SERVICE_USER, MessageResource.DELETE_FAIL), historyNumberStr);
		}
		
		List<ServiceUserHistoryModel> history = serviceUserHistory.getDetailUpdateHistory(serviceUserNumber, historyNumber);
		
		if(history != null) {
			return new ResponseEntity<>(history, HttpStatus.OK,
					MessageResource.toMessage(MessageResource.ADMIN_SERVICE_USER, MessageResource.GET_SUCCESS));
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_ACCEPTABLE,
					MessageResource.toMessage(MessageResource.ADMIN_SERVICE_USER, MessageResource.GET_NO_DATA));
		}
	}

}
