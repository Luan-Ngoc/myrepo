package com.example.demo.util;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;


/**
 * The ValidationUtil class
 */
public class ValidationUtil {
	
	private ValidationUtil() {
		
	}
	public static <T> ResponseEntity<T> processBindingResultError(BindingResult bindingResult) {

		List<FieldError> errors = bindingResult.getFieldErrors();
		List<String> message = new ArrayList<>();

		errors.forEach(error -> message.add(error.getField() + ":" + error.getDefaultMessage()));

		return new ResponseEntity<T>(null, HttpStatus.BAD_REQUEST, message.toString());
	}
}
